//{{NO_DEPENDENCIES}}
// fichier Include Microsoft Visual C++.
// Utilis?par Communication.rc
//
#define IDR_MENU1                       101
#define ID_EDITION_LOADPATH             40001
#define ID_EDITION_SAVEPATH             40002
#define ID_EDITION_SHOWPATH             40003
#define ID_EDITION_NEWTARGET            40004
#define ID_PLAY_ROBOT1			        40005
#define ID_STOP_ROBOT1                  40006
#define ID_DETECTION                    40007
#define ID_PLAY_ROBOT2                  40008
#define ID_STOP_ROBOT2                  40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
